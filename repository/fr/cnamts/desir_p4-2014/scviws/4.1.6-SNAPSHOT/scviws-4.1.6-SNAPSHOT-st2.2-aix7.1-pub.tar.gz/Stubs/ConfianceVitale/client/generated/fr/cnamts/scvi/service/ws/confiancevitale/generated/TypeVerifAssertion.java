
package fr.cnamts.scvi.service.ws.confiancevitale.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import fr.cnamts.desir.p4.contexte.siram.Assertion;
import org.w3c.dom.Element;


/**
 * <p>Java class for TypeVerifAssertion complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TypeVerifAssertion">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Options" type="{urn:siram:desir:confiancevitale}TypeOption"/>
 *         &lt;element ref="{urn:oasis:names:tc:SAML:2.0:assertion}Assertion" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TypeVerifAssertion", propOrder = {
    "options",
    "assertion"
})
public class TypeVerifAssertion {

    @XmlElement(name = "Options", required = true)
    protected TypeOption options;
    @XmlElement(name = "Assertion", namespace = "urn:oasis:names:tc:SAML:2.0:assertion", type = Assertion.class)
    protected Element assertion;

    /**
     * Gets the value of the options property.
     * 
     * @return
     *     possible object is
     *     {@link TypeOption }
     *     
     */
    public TypeOption getOptions() {
        return options;
    }

    /**
     * Sets the value of the options property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeOption }
     *     
     */
    public void setOptions(TypeOption value) {
        this.options = value;
    }

    /**
     * Gets the value of the assertion property.
     * 
     * @return
     *     possible object is
     *     {@link Assertion }
     *     
     */
    public Element getAssertion() {
        return assertion;
    }

    /**
     * Sets the value of the assertion property.
     * 
     * @param value
     *     allowed object is
     *     {@link Assertion }
     *     
     */
    public void setAssertion(Element value) {
        this.assertion = value;
    }

}
