
package fr.cnamts.scvi.service.ws.confiancevitale.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import fr.cnamts.desir.p4.contexte.siram.Assertion;
import fr.cnamts.desir.p4.contexte.siram.ContexteVitale;
import org.w3c.dom.Element;


/**
 * <p>Java class for TypeVerifOpposition complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TypeVerifOpposition">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;choice>
 *         &lt;element ref="{urn:siram:vitale:ctxvitale}ContexteVitale" minOccurs="0"/>
 *         &lt;element ref="{urn:oasis:names:tc:SAML:2.0:assertion}Assertion" minOccurs="0"/>
 *       &lt;/choice>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TypeVerifOpposition", propOrder = {
    "assertion",
    "contexteVitale"
})
public class TypeVerifOpposition {

    @XmlElement(name = "Assertion", namespace = "urn:oasis:names:tc:SAML:2.0:assertion", type = Assertion.class)
    protected Element assertion;
    @XmlElement(name = "ContexteVitale", namespace = "urn:siram:vitale:ctxvitale")
    protected ContexteVitale contexteVitale;

    /**
     * Gets the value of the assertion property.
     * 
     * @return
     *     possible object is
     *     {@link Assertion }
     *     
     */
    public Element getAssertion() {
        return assertion;
    }

    /**
     * Sets the value of the assertion property.
     * 
     * @param value
     *     allowed object is
     *     {@link Assertion }
     *     
     */
    public void setAssertion(Element value) {
        this.assertion = value;
    }

    /**
     * Gets the value of the contexteVitale property.
     * 
     * @return
     *     possible object is
     *     {@link ContexteVitale }
     *     
     */
    public ContexteVitale getContexteVitale() {
        return contexteVitale;
    }

    /**
     * Sets the value of the contexteVitale property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContexteVitale }
     *     
     */
    public void setContexteVitale(ContexteVitale value) {
        this.contexteVitale = value;
    }

}
