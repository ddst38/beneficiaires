@javax.xml.bind.annotation.XmlSchema(namespace = "urn:siram:desir:confiancevitale", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package fr.cnamts.scvi.service.ws.confiancevitale.generated;
