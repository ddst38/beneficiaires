
package fr.cnamts.scvi.service.ws.confiancevitale.generated;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the fr.cnamts.scvi.service.ws.confiancevitale.generated package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: fr.cnamts.scvi.service.ws.confiancevitale.generated
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link VerifierVITALEResponse }
     * 
     */
    public VerifierVITALEResponse createVerifierVITALEResponse() {
        return new VerifierVITALEResponse();
    }

    /**
     * Create an instance of {@link VerifierVITALERequest }
     * 
     */
    public VerifierVITALERequest createVerifierVITALERequest() {
        return new VerifierVITALERequest();
    }

    /**
     * Create an instance of {@link TypeVerifAssertion }
     * 
     */
    public TypeVerifAssertion createTypeVerifAssertion() {
        return new TypeVerifAssertion();
    }

    /**
     * Create an instance of {@link TypeVerifOpposition }
     * 
     */
    public TypeVerifOpposition createTypeVerifOpposition() {
        return new TypeVerifOpposition();
    }

    /**
     * Create an instance of {@link TypeOption }
     * 
     */
    public TypeOption createTypeOption() {
        return new TypeOption();
    }

}
