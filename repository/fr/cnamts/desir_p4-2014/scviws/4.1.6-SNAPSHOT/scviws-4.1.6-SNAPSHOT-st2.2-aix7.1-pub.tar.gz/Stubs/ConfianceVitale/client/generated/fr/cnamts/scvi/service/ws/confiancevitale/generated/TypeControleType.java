
package fr.cnamts.scvi.service.ws.confiancevitale.generated;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TypeControleType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TypeControleType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="opposition"/>
 *     &lt;enumeration value="assertion"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "TypeControleType")
@XmlEnum
public enum TypeControleType {

    @XmlEnumValue("opposition")
    OPPOSITION("opposition"),
    @XmlEnumValue("assertion")
    ASSERTION("assertion");
    private final String value;

    TypeControleType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TypeControleType fromValue(String v) {
        for (TypeControleType c: TypeControleType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
