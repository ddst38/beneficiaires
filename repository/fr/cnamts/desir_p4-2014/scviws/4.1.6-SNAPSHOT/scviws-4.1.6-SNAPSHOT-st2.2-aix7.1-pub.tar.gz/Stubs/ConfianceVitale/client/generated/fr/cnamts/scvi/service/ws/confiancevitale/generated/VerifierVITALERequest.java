
package fr.cnamts.scvi.service.ws.confiancevitale.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TypeverifierVITALERequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TypeverifierVITALERequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="TypeControle" type="{urn:siram:desir:confiancevitale}TypeControleType"/>
 *         &lt;element name="VerifAssertion" type="{urn:siram:desir:confiancevitale}TypeVerifAssertion" minOccurs="0"/>
 *         &lt;element name="VerifOpposition" type="{urn:siram:desir:confiancevitale}TypeVerifOpposition" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TypeverifierVITALERequest", propOrder = {
    "typeControle",
    "verifAssertion",
    "verifOpposition"
})
@XmlRootElement(name = "verifierVITALERequest")
public class VerifierVITALERequest {

    @XmlElement(name = "TypeControle", required = true)
    protected TypeControleType typeControle;
    @XmlElement(name = "VerifAssertion")
    protected TypeVerifAssertion verifAssertion;
    @XmlElement(name = "VerifOpposition")
    protected TypeVerifOpposition verifOpposition;

    /**
     * Gets the value of the typeControle property.
     * 
     * @return
     *     possible object is
     *     {@link TypeControleType }
     *     
     */
    public TypeControleType getTypeControle() {
        return typeControle;
    }

    /**
     * Sets the value of the typeControle property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeControleType }
     *     
     */
    public void setTypeControle(TypeControleType value) {
        this.typeControle = value;
    }

    /**
     * Gets the value of the verifAssertion property.
     * 
     * @return
     *     possible object is
     *     {@link TypeVerifAssertion }
     *     
     */
    public TypeVerifAssertion getVerifAssertion() {
        return verifAssertion;
    }

    /**
     * Sets the value of the verifAssertion property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeVerifAssertion }
     *     
     */
    public void setVerifAssertion(TypeVerifAssertion value) {
        this.verifAssertion = value;
    }

    /**
     * Gets the value of the verifOpposition property.
     * 
     * @return
     *     possible object is
     *     {@link TypeVerifOpposition }
     *     
     */
    public TypeVerifOpposition getVerifOpposition() {
        return verifOpposition;
    }

    /**
     * Sets the value of the verifOpposition property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeVerifOpposition }
     *     
     */
    public void setVerifOpposition(TypeVerifOpposition value) {
        this.verifOpposition = value;
    }

}
