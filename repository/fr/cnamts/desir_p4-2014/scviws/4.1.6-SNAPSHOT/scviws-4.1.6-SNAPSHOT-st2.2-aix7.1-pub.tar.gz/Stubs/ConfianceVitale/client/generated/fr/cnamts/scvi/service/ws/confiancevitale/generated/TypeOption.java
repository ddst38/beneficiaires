
package fr.cnamts.scvi.service.ws.confiancevitale.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TypeOption complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TypeOption">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Signature" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="DureeValiditeAssertion" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="DeriveHorloge" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TypeOption", propOrder = {
    "signature",
    "dureeValiditeAssertion",
    "deriveHorloge"
})
public class TypeOption {

    @XmlElement(name = "Signature")
    protected int signature;
    @XmlElement(name = "DureeValiditeAssertion")
    protected Integer dureeValiditeAssertion;
    @XmlElement(name = "DeriveHorloge")
    protected Integer deriveHorloge;

    /**
     * Gets the value of the signature property.
     * 
     */
    public int getSignature() {
        return signature;
    }

    /**
     * Sets the value of the signature property.
     * 
     */
    public void setSignature(int value) {
        this.signature = value;
    }

    /**
     * Gets the value of the dureeValiditeAssertion property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDureeValiditeAssertion() {
        return dureeValiditeAssertion;
    }

    /**
     * Sets the value of the dureeValiditeAssertion property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDureeValiditeAssertion(Integer value) {
        this.dureeValiditeAssertion = value;
    }

    /**
     * Gets the value of the deriveHorloge property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDeriveHorloge() {
        return deriveHorloge;
    }

    /**
     * Sets the value of the deriveHorloge property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDeriveHorloge(Integer value) {
        this.deriveHorloge = value;
    }

}
